-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2023 at 11:35 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`) VALUES
(7, 'admin', 'e51de772aecc7f0e3857a67b18fdf5b60961543d'),
(13, 'sharangan', 'e51de772aecc7f0e3857a67b18fdf5b60961543d');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_id`, `name`, `email`, `number`, `message`) VALUES
(3, 2, 'Sharan', 'sharan@gmail.com', '0771336598', 'I am really happy to your delivery service.\r\nfast delivery and low charges fees.'),
(4, 3, 'Kumaratharmasena', 'Kumar@gmail.com', '0763214569', 'Amazing Taste foods..!!!!!!\r\nThank you so much');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `number` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` datetime NOT NULL DEFAULT current_timestamp(),
  `payment_status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `number`, `email`, `method`, `address`, `total_products`, `total_price`, `placed_on`, `payment_status`) VALUES
(3, 5, 'Sharangan', '0769218508', 'sharan@gmail.com', 'cash on delivery', '3546, 256, wrf, rf, wrf, rf, werf - 45', 'Large Spicy Chicken Pizza (2450 x 1) - ', 2450, '2022-09-08 22:11:17', 'completed'),
(6, 6, 'Sharangan', '0769218508', 'sharan@gmail.com', 'cash on delivery', 'pannagam, 2, pannagam, jaffna, jaffna, jaffna, srilanka - 40000', 'Chicken Koththu (600 x 1) - ', 600, '2022-09-09 00:43:33', 'completed'),
(7, 6, 'Sharangan', '0769218508', 'sharan@gmail.com', 'cash on delivery', 'pannagam, 2, pannagam, jaffna, jaffna, jaffna, srilanka - 40000', 'Chicken Koththu (600 x 1) - ', 600, '2022-09-09 00:45:38', 'pending'),
(8, 7, 'admin', '0769218553', 'aav@gmail.com', 'cash on delivery', 'panngam, 2, pannagam, jffna, jaffna, fv, fdv - 121', 'Large Spicy Chicken Pizza (2450 x 1) - ', 2450, '2023-03-03 00:00:42', 'pending'),
(9, 8, 'qq', '0769218058', 'qwe@gmail.com', 'cash on delivery', 'aa, 5, aa, aa, aa, aa, aa - 4', 'Egg Koththu (450 x 1) - Large Spicy Chicken Pizza (2450 x 1) - ', 2900, '2023-10-14 11:17:26', 'pending'),
(10, 8, 'qq', '0769218058', 'qwe@gmail.com', 'cash on delivery', 'aa, 5, aa, aa, aa, aa, aa - 4', 'Vegetable Koththu (300 x 15) - ', 4500, '2023-10-14 11:18:51', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `price` int(10) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `price`, `image`) VALUES
(21, 'Chicken Koththu', 'Koththu', 600, 'sri-lankan-chicken-koththu.jpg'),
(23, 'Large Spicy Chicken Pizza', 'Pizza', 2450, 'Chicken-Pizza_exps30800_FM143298B03_11_8bC_RMS-9.jpg'),
(24, 'Matton Koththu', 'Koththu', 700, 'Chicken-Kottu-Roti-The-Flavor-Bender-Featured-Image-SQ-8-500x500.jpg'),
(25, 'Egg Koththu', 'Koththu', 450, 'egg-kottu.jpg'),
(26, 'Chicken Rice', 'Rice', 600, 'Chicken-Fried-Rice-square-FS-.jpg'),
(27, 'Matton Rice', 'Rice', 700, 'IMG_20211030_044323.jpg'),
(31, 'Chicken Noodles', 'Noodles', 650, 'maxresdefault (1).jpg'),
(32, 'Egg Noodles', 'Noodles', 500, 'veg-noodles-vegetable-noodles-recipe.jpg'),
(33, 'Vegetable Noodles', 'Noodles', 350, 'hakka-noodles-recipe.jpg'),
(34, 'Vegetable Koththu', 'Koththu', 300, 'kothu-parotta-03-922x1024.jpg'),
(35, 'Large Matton Pizza', 'Pizza', 3000, 'Pizza_pie.jpg'),
(36, 'Vegetable Pizza', 'Pizza', 1800, 'Gralic_Crust_Veggie_Pizza.jpg'),
(37, 'Vegetable Rice', 'Rice', 350, 'fried-rice-using-veggies-500x375.jpg'),
(38, 'Egg Rice', 'Rice', 400, 'egg-fried-rice-recipe.jpg'),
(39, 'Mixed Fried Rice', 'Rice', 550, 'Mixed-Vegetable-Fried-Rice-3-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` varchar(10) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `number`, `password`, `address`) VALUES
(6, 'Sharangan', 'sharan@gmail.com', '0769218508', 'e51de772aecc7f0e3857a67b18fdf5b60961543d', 'pannagam, 2, pannagam, jaffna, jaffna, jaffna, srilanka - 40000'),
(7, 'admin', 'aav@gmail.com', '0769218553', 'c68ae33867359b6a31ac3d659c403f18424311c6', 'panngam, 2, pannagam, jffna, jaffna, fv, fdv - 121'),
(8, 'qq', 'qwe@gmail.com', '0769218058', '056eafe7cf52220de2df36845b8ed170c67e23e3', 'aa, 5, aa, aa, aa, aa, aa - 4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
